import { useEffect, useRef, useState } from "react";

import { BsBuildings } from "react-icons/bs";
import { IoIosSearch } from "react-icons/io";
import { IoIosArrowForward } from "react-icons/io";
import { IoIosArrowBack } from "react-icons/io";
function App() {
  const [exchangeList, setExchangeList] = useState([]);
  const [exchangeListCopy, setExchangeListCopy] = useState([]);
  const [flag,setFlag]=useState(false)
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [searchData, setSearchData] = useState("");
  let formattedNumber = new Intl.NumberFormat("en-US", {
    notation: "compact",
    compactDisplay: "short",
  });
  const ref = useRef(null);
  const fetchData = async () => {
    const data = await fetch("http://localhost:4001/exchangeList");

    const res = await data.json();
    console.log(res);

    let filteredList = res.data.filter(
      (val) => val.data != "0" && val.name != null
    );
    let ans = filteredList.map((val) => {
      let a = formattedNumber.format(parseInt(val.data));
      val.data = a;
      return val;
    });
    setExchangeList(ans.slice(0, 352));
    setExchangeListCopy(ans.slice(0, 352));
  };
  useEffect(() => {
    fetchData();
  }, []);

  const handleRight = () => {
    // setLoading(true);
    // setTimeout(() => {
    //   setLoading(false);
    // }, 100);
    setFlag(true)
    setPage(page + 1);
    const val = document.querySelector(".rightClick");
    const val2 = document.querySelector(".leftClick");
    val.style.backgroundColor = "#03c2fc";
    val.style.color = "white";
    if (page > 1) {
      val2.style.backgroundColor = "white";
      val2.style.color = "black";
    }
  };
  const handleLeft = () => {
    // setLoading(true);
    // setTimeout(() => {
    //   setLoading(false);
    // }, 200);
    setPage(page - 1);
    const val = document.querySelector(".rightClick");
    const val2 = document.querySelector(".leftClick");
    val2.style.backgroundColor = "#03c2fc";
    val2.style.color = "white";
    if (page < exchangeList.length / 10) {
      val.style.backgroundColor = "white";
      val.style.color = "black";
    }
  };
  const handleSearch = () => {
    if (searchData.length == 0) {
      setFlag(true)
      setExchangeList(exchangeListCopy)
     
    } else {
      setFlag(false)
      let val = exchangeListCopy.filter((data) =>
        data.name.toLowerCase().includes(searchData.toLowerCase())
      );
      setExchangeList(val);
    }
  };
  useEffect(()=>{
    handleSearch()
  },[searchData])
  console.log("flag",flag)
  return (
    <div className="App flex flex-col">
      <h1 className="text-center text-gray-900 text-2xl border border-b-gray-300 py-3">
        Top Crypto Exchanges
      </h1>
      <div className="relative mx-auto w-1/3 mt-4">
        <BsBuildings className="absolute left-4 translate-y-3" />
        <input
          type="text"
          placeholder="Find an exchange "
          maxLength={20}
          onChange={(e)=>setSearchData(e.target.value)}
          className="rounded-3xl w-full border outline-none border-gray-300 pl-10 py-2 placeholder:pl-2"
        />
        <IoIosSearch onClick={handleSearch} className="absolute right-4 -translate-y-7 cursor-pointer" />
      </div>
      <div className="w-11/12 font-semibold text-lg max-w-4xl mx-auto items-center flex justify-between py-2 mt-2 border-b border-b-gray-300">
        <p>EXCHANGES</p>
        <p>24H TRADE VOLUME</p>
      </div>
      {loading ? (
        <div className="h-[70vh] w-[100vw] flex items-center justify-center">
          <p className="text-2xl">Loading...</p>
        </div>
      ) : (
        <>
          <div className="w-11/12 max-w-4xl mx-auto mt-2 flex flex-col gap-3 mb-3">
            {exchangeList.slice(page * 10 - 10, page * 10).map((data) => (
              <div
                key={data.id}
                className="flex justify-between items-center bg-gray-300 p-2"
              >
                <div className="flex gap-4 items-center">
                  <img src={data.url} alt="" />
                  <p>{data.name}</p>
                </div>
                <p>{data.data}</p>
              </div>
            ))}
          </div>
          <div className="m-4 flex mx-auto gap-6 py-1">
            {page > 1 && (
              <div
                onClick={handleLeft}
                className="flex cursor-pointer leftClick items-center justify-center gap-2 rounded-2xl border border-gray-400 px-4 py-1"
              >
                <button>Previous </button>
                <span>
                  <IoIosArrowBack />
                </span>
              </div>
            )}

            <div className="flex gap-3">
              { !searchData && flag &&[...Array(exchangeList?.length / 10)].map((_, i) => (
                <div
                  key={i + 1}
                  className={`px-3 flex items-center justify-center rounded-sm ${
                    page == i + 1 ? "bg-gray-800 text-white" : "text-black"
                  }`}
                >
                  <p>{i + 1}</p>
                </div>
              ))}
            </div>
            {page < exchangeList?.length / 10 && (
              <div
                onClick={handleRight}
                className={`flex rightClick items-center cursor-pointer py-1 justify-center gap-2 rounded-2xl border border-gray-400 px-4`}
              >
                <button>Next </button>
                <span>
                  <IoIosArrowForward />
                </span>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}

export default App;
