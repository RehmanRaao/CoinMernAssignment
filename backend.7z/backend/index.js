const express = require("express");
const mongoose = require("mongoose");
const cron = require("node-cron");
const cors = require("cors");
const app = express();

app.use(cors({ origin: "http://localhost:3001", credentials: true }));

const apiUrl = "https://rest.coinapi.io/v1/exchanges";
const apiKey = "FDAB8705-CEAA-4A23-8A5B-6CC30B8D44D9";
const iconApi = "https://rest.coinapi.io/v1/exchanges/icons/32";

const ExchangeSchema = new mongoose.Schema({
  id: { type: String, unique: true },
  name: String,
  data: String,
  url: {
    type: String,
    default:
      "https://s3.eu-central-1.amazonaws.com/bbxt-static-icons/type-id/png_32/9204ca863f464a5b844eaaf333eba2be.png",
  },
});

const Exchange = mongoose.model("Exchange", ExchangeSchema);

mongoose
  .connect("mongodb://localhost:27017/exchangesDB", {
    family: 4,
  })
  .then(() => console.log("db connected "))
  .catch((err) => console.log(err));

async function get() {
  const data = await fetch(apiUrl, {
    headers: {
      "X-CoinAPI-Key": apiKey,
    },
  });
  const res = await data.json();

  res.forEach((exchange) => {
    Exchange.findOneAndUpdate(
      { id: exchange.exchange_id },
      {
        id: exchange.exchange_id,
        name: exchange.name,
        data: exchange.volume_1day_usd,
      },
      { upsert: true, new: true }
    ).exec();
  });
  const newData = await fetch(iconApi, {
    headers: {
      "X-CoinAPI-Key": apiKey,
    },
  });
  const iconData = await newData.json();
  console.log(iconData);

  for (let i = 0; i < iconData.length; i++) {
    await Exchange.findOneAndUpdate(
      { id: iconData[i].exchange_id },
      { url: iconData[i].url }
    );
  }
}
get()
app.get("/exchangeList", async (req, res) => {
  try {
    const exchangeData = await Exchange.find({});
    res.status(200).json({
      success: true,
      data: exchangeData,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Error while fetching exchange",
    });
  }
});
// cron.schedule("0 0 * * *", get);

app.listen(4001, () => {
  console.log("running");
});
