const readline = require('readline')

const r=readline.createInterface(process.stdin,process.stdout)

// r.setPrompt(`What is your age? `);

// r.prompt();
let a=r.prompt();
let arr=[]
r.on('line', (line) => {
    line !== '' ? arr.push(line): r.close();
  }).on('close', () => {
//   const size = cmdlInput.shift();
//   const numArray = arr.map(val=>parseInt(val))
//   console.log(arr)
   arr.forEach((val)=>{
    result(val)
   })
  });

  function result(data){
    if(data.length<10){
        console.log(data)
        return
    }
    var str=""+data[0]+(data.length-2)+data[data.length-1]
    console.log(str)
}


